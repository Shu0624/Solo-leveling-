import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { HiArrowRight } from 'react-icons/hi'
import { FiTruck, FiClock, FiCheckCircle, FiHeart } from 'react-icons/fi'
import { useState, useEffect } from 'react'
import axios from 'axios'
import ProductCard from '../components/ProductCard'

// Feature strip data
const features = [
  { icon: FiTruck,       title: 'Free Delivery',      desc: 'On orders over ₹399' },
  { icon: FiClock,       title: 'Same Day Delivery',   desc: 'Order today, get today' },
  { icon: FiCheckCircle, title: '100% Quality',        desc: 'Premium ingredients' },
  { icon: FiHeart,       title: 'Made with Love',      desc: 'Every single creation' },
]

// Relationship cards — gorgeous cakes and pastries
const relationships = [
  { label: 'For Her',       img: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80' }, // Pink frosted cake (Hero image)
  { label: 'For Him',       img: 'https://images.unsplash.com/photo-1621303837174-89787a7d4729?w=400&q=80' }, // Dark chocolate cake
  { label: 'For Kids',      img: 'https://images.unsplash.com/photo-1587668178277-295251f900ce?w=400&q=80' }, // Fun confetti cupcakes
  { label: 'For Mom',       img: 'https://images.unsplash.com/photo-1519869325930-281384150729?w=400&q=80' }, // Floral elegant cake
  { label: 'For Dad',       img: 'https://images.unsplash.com/photo-1542826438-bd32f43d626f?w=400&q=80' }, // Coffee & cake
  { label: 'For BFF',       img: 'https://images.unsplash.com/photo-1550617931-e17a7b70dce2?w=400&q=80' }, // Colorful macarons
  { label: 'Anniversary',   img: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=400&q=80' }, // Tiered cake (Wedding)
  { label: 'Sweet Surprise', img: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=400&q=80' }, // Cupcakes
]

// Occasion cards — full editorial luxury cake photos
const occasions = [
  { label: 'Birthdays',   img: 'https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?w=800&q=90' }, // Birthday candles cake
  { label: 'Weddings',    img: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800&q=90' }, // Tiered wedding cake
  { label: 'Baby Shower', img: 'https://images.unsplash.com/photo-1627834377411-8da5f4f09de8?w=800&q=90' }, // Pastel whimsical cake
  { label: 'Corporate',   img: 'https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=800&q=90' }, // Modern dessert
  { label: 'Festivals',   img: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=800&q=90' }, // Assorted colorful sweets
]

const defaultAbout = {
  aboutTitle: "Baked with heart, gifted with love.",
  aboutText: "Based in Jalgaon, Maharashtra, every creation at Celestee's is a piece of our heart — made from the finest real ingredients, no shortcuts, no preservatives. Just pure love baked into every bite.",
  aboutImage: "https://images.unsplash.com/photo-1595126731402-530e8d73df40?w=1200&q=85", // Female Baker
}

export default function Home() {
  const [featured, setFeatured] = useState([])
  const [about, setAbout] = useState(defaultAbout)
  const [clients, setClients] = useState([])

  useEffect(() => {
    // Fetch bestseller products
    const fetchFeatured = async () => {
      try {
        const res = await axios.get('/api/products')
        const bests = res.data.filter(p => p.bestseller)
        setFeatured(bests.length > 0 ? bests.slice(0, 4) : res.data.slice(0, 4))
      } catch {
        try {
          const { sampleProducts } = await import('../data/products')
          setFeatured(sampleProducts.slice(0, 4))
        } catch { /* no fallback data */ }
      }
    }

    // Fetch editable about settings
    const fetchSettings = async () => {
      try {
        const res = await axios.get('/api/settings')
        if (res.data) setAbout(res.data)
      } catch { /* use defaults */ }
    }

    const fetchClients = async () => {
      try {
        const res = await axios.get('/api/clients')
        setClients(res.data)
      } catch { /* ignore */ }
    }

    fetchFeatured()
    fetchSettings()
    fetchClients()
  }, [])

  return (
    <main className="bg-[#FDFBF9]">

      {/* ── HERO ── */}
      <section className="relative h-screen flex justify-center items-center overflow-hidden w-full">
        <img
          src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?q=80&w=2000"
          alt="Signature Celestee's Cake"
          className="absolute inset-0 w-full h-full object-cover object-right"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-brown-dark/95 via-brown-dark/70 to-transparent" />

        <div className="w-full max-w-[1300px] px-5 md:px-10 relative z-10 flex">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
            className="max-w-xl md:max-w-2xl text-left pt-20"
          >
            <span className="font-display text-5xl md:text-7xl text-gold-light/30 leading-none block mb-2 font-serif">"</span>
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl leading-[1.1] text-white mb-4 md:mb-6 font-light">
              Baked with Love,<br /> Just Like Home.
            </h1>
            <p className="text-gold text-base md:text-2xl font-display italic">
              Celestee's Home Bakes, for all your sweet moments!
            </p>
            <div className="flex flex-col sm:flex-row gap-3 md:gap-4 mt-8 md:mt-10">
              <Link to="/cakes" className="px-7 md:px-8 py-3.5 md:py-4 bg-gold text-white text-[10px] md:text-xs font-semibold uppercase tracking-[0.15em] hover:bg-white hover:text-brown-dark transition-all duration-500 shadow-lg text-center">
                Explore Cakes
              </Link>
              <a href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer" className="px-7 md:px-8 py-3.5 md:py-4 border border-white/30 text-white text-[10px] md:text-xs font-semibold uppercase tracking-[0.15em] hover:bg-white/10 transition-all duration-500 text-center">
                Order on WhatsApp
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── PREMIUM FEATURE STRIP ── */}
      <section className="bg-white border-b border-brown-light/5 w-full flex justify-center">
        <div className="w-full max-w-[1300px] px-5 md:px-10 py-6 md:py-10 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-0 md:divide-x md:divide-gray-100">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="flex items-center gap-3 md:gap-4 px-0 md:px-6 md:first:pl-0 md:last:pr-0"
            >
              <div className="w-9 h-9 md:w-11 md:h-11 rounded-full bg-gold/10 flex items-center justify-center shrink-0">
                <f.icon className="w-4 h-4 md:w-5 md:h-5 text-gold" />
              </div>
              <div>
                <h4 className="text-brown-dark text-xs md:text-sm font-semibold leading-tight">{f.title}</h4>
                <p className="text-brown-light/50 text-[10px] md:text-xs mt-0.5 hidden md:block">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ── SIGNATURE BAKES (From Admin/DB) ── */}
      <section className="py-16 md:py-32 px-5 md:px-10 w-full flex justify-center">
        <div className="w-full max-w-[1300px]">
          <div className="text-center mb-10 md:mb-16">
            <p className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-3 md:mb-4 font-semibold">Celestee's Collection</p>
            <h2 className="font-display text-3xl md:text-5xl lg:text-6xl text-brown-dark leading-tight font-light">Signature Bakes</h2>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-x-6 md:gap-y-8 mb-12 md:mb-20">
            {featured.length > 0 
              ? featured.map((p, i) => <ProductCard key={p._id || i} product={p} index={i} />)
              : Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="aspect-[4/5] bg-cream/50 animate-pulse rounded-sm" />
                ))
            }
          </div>

          <div className="text-center">
            <Link to="/cakes" className="inline-flex items-center justify-center gap-3 px-10 md:px-12 py-3.5 md:py-4 bg-brown-dark text-white hover:bg-gold transition-all duration-500 font-semibold uppercase tracking-[0.15em] text-[10px] md:text-xs shadow-sm hover:shadow-lg">
              View All Bakes <HiArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── FOR EVERY RELATIONSHIP ── */}
      <section className="py-20 md:py-28 w-full bg-[#F9F5F8] border-t border-pink-soft/20 flex justify-center">
        <div className="w-full max-w-[1300px] px-6 md:px-10">
          <div className="flex items-end justify-between mb-14">
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] text-brown-light/50 mb-3">A Cake For</p>
              <h2 className="font-display text-3xl md:text-5xl text-brown-dark">Every Relationship</h2>
            </div>
            <Link to="/cakes" className="hidden md:flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-brown-dark/60 hover:text-gold transition-colors">
              Shop All <HiArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Portrait circle list */}
          <div className="flex gap-4 md:gap-8 overflow-x-auto pb-8 scrollbar-hide">
            {relationships.map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="group shrink-0"
              >
                <Link to="/cakes" className="flex flex-col items-center gap-3 cursor-pointer">
                  <div className="w-28 h-28 md:w-36 md:h-36 rounded-full overflow-hidden border-[3px] border-white shadow-md group-hover:border-gold transition-all duration-300 group-hover:shadow-[0_0_0_4px_rgba(198,167,105,0.25)]">
                    <img src={r.img} alt={r.label} className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500" />
                  </div>
                  <span className="text-xs font-semibold text-brown-dark tracking-wide">{r.label}</span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CAKE FOR EVERY OCCASION ── */}
      <section className="py-16 md:py-28 w-full bg-brown-dark flex justify-center overflow-hidden">
        <div className="w-full max-w-[1400px] px-5 md:px-10">
          
          {/* Header */}
          <div className="text-center mb-10 md:mb-16">
            <p className="text-[9px] md:text-[10px] uppercase tracking-[0.5em] text-gold mb-3 md:mb-4 font-semibold">Curated For You</p>
            <h2 className="font-display text-3xl md:text-5xl lg:text-6xl text-white font-light">Every Occasion</h2>
          </div>

          {/* Premium staggered grid */}
          <div className="grid grid-cols-2 md:grid-cols-12 gap-2 md:gap-3">
            
            {/* Birthdays — large left card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="col-span-2 md:col-span-5 md:row-span-2 group relative overflow-hidden h-[280px] md:h-[600px]"
            >
              <Link to="/cakes" className="block w-full h-full relative">
                <img src={occasions[0].img} alt={occasions[0].label} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2.5s] ease-out" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/5 group-hover:from-black/60 transition-all duration-1000" />
                {/* Gold line accent */}
                <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-1000 ease-out" />
                <div className="absolute inset-0 flex flex-col items-start justify-end p-6 md:p-10">
                  <p className="text-[8px] md:text-[9px] font-semibold uppercase tracking-[0.5em] text-gold mb-2 opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-700 delay-100">Explore</p>
                  <h3 className="font-display text-3xl md:text-5xl text-white font-light tracking-wide">{occasions[0].label}</h3>
                  <div className="w-8 h-[1px] bg-gold/50 mt-3 md:mt-4" />
                </div>
              </Link>
            </motion.div>

            {/* Weddings — top right */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="col-span-1 md:col-span-4 group relative overflow-hidden h-[200px] md:h-[290px]"
            >
              <Link to="/cakes" className="block w-full h-full relative">
                <img src={occasions[1].img} alt={occasions[1].label} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2.5s] ease-out" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent group-hover:from-black/60 transition-all duration-1000" />
                <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-1000 ease-out" />
                <div className="absolute inset-0 flex flex-col items-start justify-end p-5 md:p-8">
                  <p className="text-[8px] md:text-[9px] font-semibold uppercase tracking-[0.5em] text-gold mb-1.5 opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-700 delay-100">Explore</p>
                  <h3 className="font-display text-xl md:text-3xl text-white font-light tracking-wide">{occasions[1].label}</h3>
                </div>
              </Link>
            </motion.div>

            {/* Baby Shower — middle right */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.15, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="col-span-1 md:col-span-3 group relative overflow-hidden h-[200px] md:h-[290px]"
            >
              <Link to="/cakes" className="block w-full h-full relative">
                <img src={occasions[2].img} alt={occasions[2].label} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2.5s] ease-out" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent group-hover:from-black/60 transition-all duration-1000" />
                <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-1000 ease-out" />
                <div className="absolute inset-0 flex flex-col items-start justify-end p-5 md:p-8">
                  <p className="text-[8px] md:text-[9px] font-semibold uppercase tracking-[0.5em] text-gold mb-1.5 opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-700 delay-100">Explore</p>
                  <h3 className="font-display text-xl md:text-3xl text-white font-light tracking-wide">{occasions[2].label}</h3>
                </div>
              </Link>
            </motion.div>

            {/* Corporate — bottom right wide */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="col-span-1 md:col-span-3 group relative overflow-hidden h-[200px] md:h-[290px]"
            >
              <Link to="/cakes" className="block w-full h-full relative">
                <img src={occasions[3].img} alt={occasions[3].label} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2.5s] ease-out" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent group-hover:from-black/60 transition-all duration-1000" />
                <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-1000 ease-out" />
                <div className="absolute inset-0 flex flex-col items-start justify-end p-5 md:p-8">
                  <p className="text-[8px] md:text-[9px] font-semibold uppercase tracking-[0.5em] text-gold mb-1.5 opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-700 delay-100">Explore</p>
                  <h3 className="font-display text-xl md:text-3xl text-white font-light tracking-wide">{occasions[3].label}</h3>
                </div>
              </Link>
            </motion.div>

            {/* Festivals — bottom right */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.25, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="col-span-1 md:col-span-4 group relative overflow-hidden h-[200px] md:h-[290px]"
            >
              <Link to="/cakes" className="block w-full h-full relative">
                <img src={occasions[4].img} alt={occasions[4].label} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2.5s] ease-out" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent group-hover:from-black/60 transition-all duration-1000" />
                <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-1000 ease-out" />
                <div className="absolute inset-0 flex flex-col items-start justify-end p-5 md:p-8">
                  <p className="text-[8px] md:text-[9px] font-semibold uppercase tracking-[0.5em] text-gold mb-1.5 opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-700 delay-100">Explore</p>
                  <h3 className="font-display text-xl md:text-3xl text-white font-light tracking-wide">{occasions[4].label}</h3>
                </div>
              </Link>
            </motion.div>

          </div>
        </div>
      </section>

      {/* ── HAPPY CLIENTS ── */}
      {clients.length > 0 && (
        <section className="py-20 md:py-28 w-full bg-[#FFFBF7] flex justify-center border-t border-pink-soft/20 overflow-hidden">
          <div className="w-full max-w-[1300px] px-6 md:px-10">
            <div className="text-center mb-16">
              <p className="text-[10px] uppercase tracking-[0.3em] text-brown-light/50 mb-3">Testimonials</p>
              <h2 className="font-display text-4xl md:text-5xl text-brown-dark">Happy Clients</h2>
            </div>
            
            <div className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide snap-x">
              {clients.map((c, i) => (
                <motion.div
                  key={c._id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-[24px] p-8 border border-pink-soft/30 shadow-sm shrink-0 w-[300px] md:w-[380px] snap-center flex flex-col items-center text-center"
                >
                  <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-pink-soft mb-6 shrink-0">
                    <img src={c.image} alt={c.name} className="w-full h-full object-cover" />
                  </div>
                  <p className="text-brown-light/80 italic text-sm md:text-base leading-relaxed mb-6 font-light">"{c.review}"</p>
                  <h4 className="font-display text-brown-dark text-lg">{c.name}</h4>
                  <div className="text-gold text-sm mt-1">★★★★★</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── OUR STORY — Full-Width 50/50 Split (Admin Editable) ── */}
      <section className="w-full flex justify-center border-t border-pink-soft/20">
        <div className="w-full max-w-[1600px] flex flex-col lg:flex-row min-h-[580px]">
          {/* Left: Text */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex-1 flex flex-col justify-center px-10 md:px-16 lg:px-24 py-24 bg-[#FDFBF9]"
          >
            <p className="text-[10px] uppercase tracking-[0.3em] text-gold-light mb-6">Our Story</p>
            <h2 className="font-display text-4xl md:text-5xl text-brown-dark leading-tight mb-8">
              {about.aboutTitle}
            </h2>
            <p className="text-brown-light/80 text-base md:text-lg leading-[1.9] mb-8 font-light max-w-md">
              {about.aboutText}
            </p>
            <Link to="/about" className="inline-flex items-center gap-3 text-xs font-semibold uppercase tracking-widest text-brown-dark hover:text-gold transition-colors pb-1 border-b border-brown-dark/30 hover:border-gold w-fit">
              Read Our Full Story <HiArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>

          {/* Right: Edge-to-Edge Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex-1 relative min-h-[400px] lg:min-h-0"
          >
            <img
              src={about.aboutImage}
              alt="Baker with her creation"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent to-brown-dark/5" />
          </motion.div>
        </div>
      </section>

    </main>
  )
}
