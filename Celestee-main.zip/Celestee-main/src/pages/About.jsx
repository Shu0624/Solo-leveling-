import { motion } from 'framer-motion'

const values = [
  { title: 'Pure Ingredients', desc: 'Sourced from the finest local and international suppliers. No shortcuts, ever.' },
  { title: 'Handcrafted Joy', desc: 'Every batter, frosting, and decoration is meticulously created by hand.' },
  { title: 'Uncompromising Quality', desc: 'Baked strictly on the day of delivery to guarantee absolute freshness.' },
]

export default function About() {
  return (
    <main className="pt-20 md:pt-24 bg-[#FDFBF9] min-h-screen">

      {/* Hero Header */}
      <section className="py-16 md:py-24 px-5 md:px-6 text-center">
        <motion.p 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} 
          className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-4 md:mb-6 font-semibold"
        >About Us</motion.p>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="font-display text-4xl md:text-6xl lg:text-7xl text-brown-dark mb-5 md:mb-6 leading-tight font-light"
        >
          Our Story
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="text-brown-light/70 text-sm md:text-base max-w-xl mx-auto font-light leading-[1.8]"
        >
          A passion for perfection, born in a home kitchen and nurtured by the love of our community.
        </motion.p>
      </section>

      {/* Story Section */}
      <section className="py-12 md:py-32 px-5 md:px-10 w-full flex justify-center">
        <div className="w-full max-w-[1300px] grid grid-cols-1 lg:grid-cols-2 gap-10 md:gap-16 lg:gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="relative"
          >
            <div className="overflow-hidden aspect-[4/5] border border-brown-light/5 shadow-[0_20px_50px_-15px_rgba(0,0,0,0.08)]">
              <img
                src="https://images.unsplash.com/photo-1556217477-d325251ece38?w=900&q=80"
                alt="Baker preparing cake"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <div className="w-8 h-[1px] bg-gold mb-6 md:mb-8" />
            <h2 className="font-display text-3xl md:text-4xl leading-tight mb-6 md:mb-8 text-brown-dark font-light">
              We don't just bake cakes.<br className="hidden md:block" /> We craft memories.
            </h2>
            <div className="space-y-4 md:space-y-6 text-brown-light/70 text-sm md:text-base leading-[1.9] font-light">
              <p>
                It started as a simple desire to bake better, fresher, and more beautiful treats for our own family. We realized that mass-produced cakes lacked the soul and taste of a true home-baked masterpiece.
              </p>
              <p>
                Today, Celestee's Home Bakes is dedicated to elevating the standard of desserts in Jalgaon. We believe that what goes into the mixing bowl matters immensely — which is why we strictly refuse to use artificial preservatives.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-16 md:py-32 px-5 md:px-10 bg-brown-dark w-full flex justify-center">
        <div className="w-full max-w-[1300px] grid grid-cols-1 lg:grid-cols-3 gap-10 md:gap-16">
          <div className="lg:col-span-1">
            <p className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-4 font-semibold">Our Values</p>
            <h2 className="font-display text-3xl md:text-4xl text-white mb-4 md:mb-6 font-light">Our Core Philosophy</h2>
            <p className="text-white/40 font-light leading-[1.8] text-sm">
              We adhere strictly to three guiding principles that form the foundation of everything we pull out of our ovens.
            </p>
          </div>
          <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-10">
            {values.map((v, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
              >
                <div className="w-8 h-[1px] bg-gold mb-5 md:mb-6" />
                <h3 className="font-display text-lg md:text-xl text-white mb-3">{v.title}</h3>
                <p className="text-white/40 text-xs md:text-sm leading-[1.8] font-light">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Photo Grid */}
      <section className="py-16 md:py-32 px-5 max-w-[1300px] mx-auto">
        <div className="text-center mb-10 md:mb-16">
          <p className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-3 font-semibold">Gallery</p>
          <h2 className="font-display text-3xl md:text-4xl text-brown-dark font-light">Moments of Joy</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
          {[
            'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600&q=80',
            'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=600&q=80',
            'https://images.unsplash.com/photo-1519869325930-281384150729?w=600&q=80',
            'https://images.unsplash.com/photo-1587668178277-295251f900ce?w=600&q=80'
          ].map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
              className="aspect-[4/5] overflow-hidden group"
            >
              <img src={img} alt="Gallery" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2s] ease-out" />
            </motion.div>
          ))}
        </div>
      </section>
    </main>
  )
}
