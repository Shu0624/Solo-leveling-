import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import axios from 'axios'
import {
  HiLogout, HiRefresh, HiOutlinePlus,
  HiOutlineCollection, HiOutlineClipboardList, HiOutlinePhotograph, HiOutlineUserGroup
} from 'react-icons/hi'

const STATUS_COLORS = {
  pending:   'bg-yellow-100 text-yellow-800',
  confirmed: 'bg-blue-100 text-blue-800',
  delivered: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
}

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('orders')

  // Orders State
  const [orders, setOrders] = useState([])

  // Products State
  const [products, setProducts] = useState([])
  const [newProduct, setNewProduct] = useState({
    name: '', price: '', category: 'cakes', image: '', description: '', bestseller: false, featured: false, tags: ''
  })

  // Clients State
  const [clients, setClients] = useState([])
  const [newClient, setNewClient] = useState({ name: '', image: '', review: '' })

  // About/Settings State
  const [settings, setSettings] = useState({ aboutTitle: '', aboutText: '', aboutImage: '' })
  const [settingsSaved, setSettingsSaved] = useState(false)

  // Global State
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const token = localStorage.getItem('adminToken')

  useEffect(() => {
    if (!token) { navigate('/admin'); return }
    fetchData()
  }, [token, activeTab])

  const fetchData = async () => {
    setLoading(true)
    setError('')
    try {
      if (activeTab === 'orders') {
        const res = await axios.get('/api/orders', { headers: { Authorization: `Bearer ${token}` } })
        setOrders(res.data)
      } else if (activeTab === 'products') {
        const res = await axios.get('/api/products')
        setProducts(res.data)
      } else if (activeTab === 'clients') {
        const res = await axios.get('/api/clients')
        setClients(res.data)
      } else if (activeTab === 'about') {
        const res = await axios.get('/api/settings')
        setSettings(res.data)
      }
    } catch {
      setError('Failed to load data. Please log in again.')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('adminToken')
    navigate('/admin')
  }

  // Orders Methods
  const updateStatus = async (id, status) => {
    try {
      await axios.put(`/api/orders/${id}`, { status }, { headers: { Authorization: `Bearer ${token}` } })
      setOrders(prev => prev.map(o => o._id === id ? { ...o, status } : o))
    } catch {
      alert('Could not update order status.')
    }
  }

  // Products Methods
  const handleAddProduct = async (e) => {
    e.preventDefault()
    try {
      const res = await axios.post('/api/products', {
        ...newProduct,
        price: Number(newProduct.price),
        tags: newProduct.tags ? newProduct.tags.split(',').map(t => t.trim()).filter(Boolean) : []
      }, { headers: { Authorization: `Bearer ${token}` } })
      setProducts([res.data, ...products])
      setNewProduct({ name: '', price: '', category: 'cakes', image: '', description: '', bestseller: false, featured: false, tags: '' })
      alert('Product Added Successfully!')
    } catch {
      alert('Failed to add product. Ensure all fields are filled.')
    }
  }

  const handleDeleteProduct = async (id) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return
    try {
      await axios.delete(`/api/products/${id}`, { headers: { Authorization: `Bearer ${token}` } })
      setProducts(prev => prev.filter(p => p._id !== id))
    } catch {
      alert('Failed to delete product.')
    }
  }

  // Clients Methods
  const handleAddClient = async (e) => {
    e.preventDefault()
    try {
      const res = await axios.post('/api/clients', newClient, { headers: { Authorization: `Bearer ${token}` } })
      setClients([res.data, ...clients])
      setNewClient({ name: '', image: '', review: '' })
      alert('Client Added Successfully!')
    } catch {
      alert('Failed to add client. Ensure all fields are filled.')
    }
  }

  const handleDeleteClient = async (id) => {
    if (!window.confirm('Are you sure you want to delete this client?')) return
    try {
      await axios.delete(`/api/clients/${id}`, { headers: { Authorization: `Bearer ${token}` } })
      setClients(prev => prev.filter(c => c._id !== id))
    } catch {
      alert('Failed to delete client.')
    }
  }

  // Settings Methods
  const handleSaveSettings = async (e) => {
    e.preventDefault()
    try {
      await axios.put('/api/settings', settings, { headers: { Authorization: `Bearer ${token}` } })
      setSettingsSaved(true)
      setTimeout(() => setSettingsSaved(false), 3000)
    } catch {
      alert('Failed to save settings.')
    }
  }

  // Sidebar nav items
  const navTabs = [
    { key: 'orders',   icon: HiOutlineClipboardList, label: 'Orders' },
    { key: 'products', icon: HiOutlineCollection,    label: 'Products' },
    { key: 'clients',  icon: HiOutlineUserGroup,     label: 'Happy Clients' },
    { key: 'about',    icon: HiOutlinePhotograph,    label: 'About Section' },
  ]

  return (
    <main className="min-h-screen bg-cream flex flex-col">
      
      {/* Top Navbar */}
      <div className="bg-white border-b border-pink-soft/50 px-6 py-4 flex items-center justify-between sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-4">
          <img src="/logo.jpg" alt="Celestee's" className="h-9 object-contain" />
          <div>
            <h1 className="font-display text-xl text-brown-dark">Admin Dashboard</h1>
            <p className="text-[10px] text-brown-light uppercase tracking-widest">Store Management</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchData} className="p-2 text-brown hover:text-gold transition-colors rounded-full hover:bg-cream" title="Refresh">
            <HiRefresh className="w-5 h-5" />
          </button>
          <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-full text-xs font-semibold hover:bg-red-500 hover:text-white transition-all uppercase tracking-widest">
            <HiLogout className="w-4 h-4" /> Logout
          </button>
        </div>
      </div>

      <div className="flex flex-1">
        
        {/* Sidebar with icon tabs */}
        <aside className="w-20 md:w-60 bg-white border-r border-pink-soft/30 flex flex-col pt-8 shrink-0">
          {navTabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-3 px-4 md:px-6 py-4 text-left transition-all group relative ${
                activeTab === tab.key
                  ? 'text-pink-deep bg-pink-soft/20 border-r-2 border-pink-deep font-semibold'
                  : 'text-brown-light hover:text-brown-dark hover:bg-cream/60'
              }`}
            >
              <tab.icon className={`w-5 h-5 shrink-0 ${activeTab === tab.key ? 'text-pink-deep' : 'text-brown-light/60 group-hover:text-brown-dark'}`} />
              <span className="hidden md:block text-[11px] uppercase tracking-[0.15em]">{tab.label}</span>
              {/* Mobile tooltip */}
              <span className="md:hidden absolute left-full ml-2 px-2 py-1 bg-brown-dark text-white text-[10px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
                {tab.label}
              </span>
            </button>
          ))}
        </aside>

        {/* Main Content */}
        <div className="flex-1 p-6 md:p-10 overflow-auto">
          
          {loading ? (
            <div className="text-center py-24 text-brown-light">Loading data…</div>
          ) : error ? (
            <div className="text-center py-24 text-red-500">{error}</div>
          ) : (
            <AnimatePresence mode="wait">

              {/* ── ORDERS TAB ── */}
              {activeTab === 'orders' && (
                <motion.div key="orders" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                  <h2 className="font-display text-3xl text-brown-dark mb-8">Orders</h2>
                  {orders.length === 0 ? (
                    <div className="text-center py-24 bg-white rounded-3xl border border-pink-soft">
                      <span className="text-5xl block mb-4">📋</span>
                      <p className="font-display text-2xl text-brown-dark">No orders yet</p>
                    </div>
                  ) : (
                    <div className="bg-white rounded-[24px] border border-pink-soft overflow-hidden shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)]">
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-pink-soft bg-cream/30">
                              {['Order', 'Customer', 'Items & Cust.', 'Total', 'Status', 'Actions'].map(h => (
                                <th key={h} className="text-left px-6 py-5 text-[10px] uppercase tracking-widest text-brown-light/80 font-semibold">{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {orders.map((order) => (
                              <tr key={order._id} className="border-b border-pink-soft/30 hover:bg-cream/10 transition-colors">
                                <td className="px-6 py-4 text-brown text-xs font-mono">#{order._id?.slice(-6).toUpperCase()}</td>
                                <td className="px-6 py-4">
                                  <p className="text-brown-dark font-medium">{order.customerName || 'N/A'}</p>
                                  <p className="text-brown-light/80 text-xs">{order.phone || ''}</p>
                                </td>
                                <td className="px-6 py-4 text-brown-light text-xs max-w-[220px]">
                                  {order.items?.map(it => `${it.name} ×${it.quantity || 1}`).join(', ') || 'N/A'}
                                  {order.message && (
                                    <div className="mt-1.5 p-2 bg-pink-soft/20 rounded border border-pink-soft/30 text-[10px] leading-relaxed italic">
                                      {order.message}
                                    </div>
                                  )}
                                </td>
                                <td className="px-6 py-4 font-display text-brown-dark font-semibold">₹{(order.total || 0).toLocaleString()}</td>
                                <td className="px-6 py-4">
                                  <span className={`px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider ${STATUS_COLORS[order.status] || 'bg-gray-100 text-gray-700'}`}>
                                    {order.status}
                                  </span>
                                </td>
                                <td className="px-6 py-4">
                                  <select value={order.status} onChange={e => updateStatus(order._id, e.target.value)} className="text-xs border border-pink-soft rounded-lg px-2 py-1.5 text-brown bg-white focus:border-pink-deep">
                                    {['pending', 'confirmed', 'delivered', 'cancelled'].map(s => (
                                      <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
                                    ))}
                                  </select>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {/* ── PRODUCTS TAB ── */}
              {activeTab === 'products' && (
                <motion.div key="products" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  
                  {/* Add Product Form */}
                  <div className="lg:col-span-1 bg-white rounded-[24px] border border-pink-soft p-6 md:p-8 shadow-sm h-fit sticky top-24">
                    <h2 className="font-display text-2xl text-brown-dark mb-6 flex items-center gap-2">
                      <HiOutlinePlus className="text-pink-deep" /> Add Product
                    </h2>
                    <form onSubmit={handleAddProduct} className="space-y-5">
                      <div>
                        <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Product Name</label>
                        <input type="text" required value={newProduct.name} onChange={e=>setNewProduct({...newProduct, name: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep" placeholder="e.g., Chocolate Truffle Cake" />
                      </div>
                      <div className="flex gap-4">
                        <div className="flex-1">
                          <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Price (₹)</label>
                          <input type="number" required value={newProduct.price} onChange={e=>setNewProduct({...newProduct, price: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep" placeholder="500" />
                        </div>
                        <div className="flex-1">
                          <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Category</label>
                          <select value={newProduct.category} onChange={e=>setNewProduct({...newProduct, category: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep bg-white">
                            <option value="cakes">Cakes</option>
                            <option value="cupcakes">Cupcakes</option>
                            <option value="donuts">Donuts</option>
                            <option value="pastries">Pastries</option>
                            <option value="custom">Custom Tiers</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Image URL</label>
                        <input type="url" required value={newProduct.image} onChange={e=>setNewProduct({...newProduct, image: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep placeholder:text-gray-300" placeholder="https://images.unsplash.com/..." />
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Short Description</label>
                        <textarea required value={newProduct.description} onChange={e=>setNewProduct({...newProduct, description: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep h-20 resize-none" placeholder="Rich chocolate layers..." />
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Tags (Comma Separated)</label>
                        <input type="text" value={newProduct.tags} onChange={e=>setNewProduct({...newProduct, tags: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep" placeholder="e.g., Mom, Birthday, Anniversary" />
                      </div>
                      <div className="space-y-3">
                        <label className="flex items-center gap-3 cursor-pointer">
                          <input type="checkbox" checked={newProduct.bestseller} onChange={e=>setNewProduct({...newProduct, bestseller: e.target.checked})} className="w-4 h-4 text-pink-deep rounded" />
                          <span className="text-sm text-brown-dark font-medium">★ Mark as Bestseller</span>
                        </label>
                        <label className="flex items-center gap-3 cursor-pointer">
                          <input type="checkbox" checked={newProduct.featured} onChange={e=>setNewProduct({...newProduct, featured: e.target.checked})} className="w-4 h-4 text-pink-deep rounded" />
                          <span className="text-sm text-brown-dark font-medium">🏠 Feature on Homepage</span>
                        </label>
                      </div>
                      <button type="submit" className="w-full py-3 rounded-full bg-pink-deep text-white font-semibold uppercase tracking-widest text-xs hover:bg-brown-dark transition-colors mt-4">
                        Save Product
                      </button>
                    </form>
                  </div>

                  {/* Products List Grid */}
                  <div className="lg:col-span-2">
                    <h2 className="font-display text-3xl text-brown-dark mb-6">All Products ({products.length})</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {products.map((p) => (
                        <div key={p._id} className="bg-white rounded-[20px] p-4 border border-pink-soft/30 flex gap-4 items-center shadow-sm">
                          <img src={p.image} alt={p.name} className="w-20 h-20 rounded-[12px] object-cover bg-cream shrink-0" />
                          <div className="flex-1 min-w-0">
                            <h3 className="font-display text-brown-dark font-medium leading-tight mb-1 truncate">{p.name}</h3>
                            <p className="text-xs text-brown-light/60 capitalize mb-1">{p.category}</p>
                            <p className="font-semibold text-pink-deep text-sm mb-2">₹{p.price}</p>
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex gap-2 flex-wrap">
                                {p.bestseller && <span className="text-[9px] text-pink-deep font-bold tracking-widest uppercase bg-pink-soft/30 px-2 py-0.5 rounded-full">★ Best</span>}
                                {p.featured && <span className="text-[9px] text-gold font-bold tracking-widest uppercase bg-gold/10 px-2 py-0.5 rounded-full">🏠 Home</span>}
                              </div>
                              <button onClick={() => handleDeleteProduct(p._id)} className="text-[10px] uppercase font-semibold text-red-400 hover:text-red-600 transition-colors shrink-0">Delete</button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    {products.length === 0 && (
                      <div className="text-center py-24 text-brown-light/60">No products in database. Add one!</div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* ── CLIENTS TAB ── */}
              {activeTab === 'clients' && (
                <motion.div key="clients" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Add Client Form */}
                  <div className="lg:col-span-1 bg-white rounded-[24px] border border-pink-soft p-6 md:p-8 shadow-sm h-fit sticky top-24">
                    <h2 className="font-display text-2xl text-brown-dark mb-6 flex items-center gap-2">
                      <HiOutlinePlus className="text-pink-deep" /> Add Client
                    </h2>
                    <form onSubmit={handleAddClient} className="space-y-5">
                      <div>
                        <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Client Name</label>
                        <input type="text" required value={newClient.name} onChange={e=>setNewClient({...newClient, name: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep" placeholder="e.g., Sarah Jenkins" />
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Image URL</label>
                        <input type="url" required value={newClient.image} onChange={e=>setNewClient({...newClient, image: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep placeholder:text-gray-300" placeholder="https://images.unsplash.com/..." />
                      </div>
                      <div>
                        <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Review (Optional)</label>
                        <textarea value={newClient.review} onChange={e=>setNewClient({...newClient, review: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep h-20 resize-none" placeholder="Amazing cake!" />
                      </div>
                      <button type="submit" className="w-full py-3 rounded-full bg-pink-deep text-white font-semibold uppercase tracking-widest text-xs hover:bg-brown-dark transition-colors mt-4">
                        Save Client
                      </button>
                    </form>
                  </div>
                  {/* Clients List */}
                  <div className="lg:col-span-2">
                    <h2 className="font-display text-3xl text-brown-dark mb-6">Happy Clients ({clients.length})</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {clients.map((c) => (
                        <div key={c._id} className="bg-white rounded-[20px] p-4 border border-pink-soft/30 flex gap-4 items-center shadow-sm">
                          <img src={c.image} alt={c.name} className="w-20 h-20 rounded-full object-cover bg-cream shrink-0 border-2 border-pink-soft" />
                          <div className="flex-1 min-w-0">
                            <h3 className="font-display text-brown-dark font-medium leading-tight mb-1 truncate">{c.name}</h3>
                            <p className="text-xs text-brown-light/60 italic line-clamp-2 mb-2">"{c.review || 'No review'}"</p>
                            <button onClick={() => handleDeleteClient(c._id)} className="text-[10px] uppercase font-semibold text-red-400 hover:text-red-600 transition-colors shrink-0">Delete</button>
                          </div>
                        </div>
                      ))}
                    </div>
                    {clients.length === 0 && (
                      <div className="text-center py-24 text-brown-light/60">No clients yet. Add one!</div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* ── ABOUT SETTINGS TAB ── */}
              {activeTab === 'about' && (
                <motion.div key="about" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="max-w-2xl">
                  <h2 className="font-display text-3xl text-brown-dark mb-2">About Section</h2>
                  <p className="text-brown-light/70 text-sm mb-8">Edit the "Our Story" block that appears on the Homepage.</p>

                  <form onSubmit={handleSaveSettings} className="bg-white rounded-[24px] border border-pink-soft p-8 shadow-sm space-y-6">
                    <div>
                      <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Headline / Title</label>
                      <input
                        type="text"
                        value={settings.aboutTitle}
                        onChange={e => setSettings({ ...settings, aboutTitle: e.target.value })}
                        className="w-full border border-brown-light/20 rounded-lg px-4 py-3 text-sm focus:border-pink-deep font-display"
                        placeholder="Baked with heart, gifted with love."
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Story Text</label>
                      <textarea
                        value={settings.aboutText}
                        onChange={e => setSettings({ ...settings, aboutText: e.target.value })}
                        rows={5}
                        className="w-full border border-brown-light/20 rounded-lg px-4 py-3 text-sm focus:border-pink-deep resize-none leading-relaxed"
                        placeholder="Tell your story here..."
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Right-Side Image URL</label>
                      <input
                        type="url"
                        value={settings.aboutImage}
                        onChange={e => setSettings({ ...settings, aboutImage: e.target.value })}
                        className="w-full border border-brown-light/20 rounded-lg px-4 py-3 text-sm focus:border-pink-deep"
                        placeholder="https://images.unsplash.com/..."
                      />
                      {settings.aboutImage && (
                        <div className="mt-3 rounded-xl overflow-hidden h-40 border border-pink-soft/30">
                          <img src={settings.aboutImage} alt="Preview" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>

                    <button
                      type="submit"
                      className={`w-full py-3.5 rounded-full font-semibold uppercase tracking-widest text-xs transition-all ${
                        settingsSaved
                          ? 'bg-green-500 text-white'
                          : 'bg-pink-deep text-white hover:bg-brown-dark'
                      }`}
                    >
                      {settingsSaved ? '✓ Saved Successfully!' : 'Save About Section'}
                    </button>
                  </form>
                </motion.div>
              )}

            </AnimatePresence>
          )}
        </div>
      </div>
    </main>
  )
}
