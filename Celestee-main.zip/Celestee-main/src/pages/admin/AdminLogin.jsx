import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import axios from 'axios'

export default function AdminLogin() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await axios.post('/api/auth/login', form)
      localStorage.setItem('adminToken', res.data.token)
      navigate('/admin/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid credentials. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-cream flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <div className="text-center mb-10">
          <img src="/logo.jpg" alt="Celestee's" className="h-16 mx-auto mb-4 object-contain" />
          <h1 className="font-display text-3xl text-brown-dark">Admin Portal</h1>
          <p className="text-brown-light text-xs mt-2 uppercase tracking-widest">Celestee's Home Bakes</p>
        </div>

        <div className="bg-white rounded-3xl p-8 shadow-sm border border-pink-soft">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-[10px] uppercase tracking-widest text-gold block mb-2">Email</label>
              <input
                type="email"
                required
                placeholder="admin@celestees.com"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                className="w-full border border-pink-soft rounded-xl px-4 py-3 text-brown text-sm focus:outline-none focus:border-gold bg-cream/50"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-widest text-gold block mb-2">Password</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                className="w-full border border-pink-soft rounded-xl px-4 py-3 text-brown text-sm focus:outline-none focus:border-gold bg-cream/50"
              />
            </div>

            {error && (
              <p className="text-red-500 text-xs text-center bg-red-50 py-2 px-4 rounded-lg">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full justify-center"
            >
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>
        </div>

        <p className="text-center text-brown-light text-[10px] mt-6 uppercase tracking-widest">
          Secured Admin Access Only
        </p>
      </motion.div>
    </main>
  )
}
