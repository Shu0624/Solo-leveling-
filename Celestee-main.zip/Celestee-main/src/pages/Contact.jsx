import { motion } from 'framer-motion'
import { FaWhatsapp, FaMapMarkerAlt, FaEnvelope, FaPhoneAlt } from 'react-icons/fa'

export default function Contact() {
  return (
    <main className="pt-20 md:pt-24 bg-[#FDFBF9] min-h-screen">
      
      {/* Header */}
      <section className="py-16 md:py-24 px-5 md:px-6 text-center">
        <motion.p 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} 
          className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-4 md:mb-6 font-semibold"
        >Contact Us</motion.p>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="font-display text-4xl md:text-6xl lg:text-7xl text-brown-dark mb-5 md:mb-6 leading-tight font-light"
        >
          Let's Connect
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="text-brown-light/70 text-sm md:text-base max-w-xl mx-auto font-light leading-[1.8]"
        >
          We'd love to hear about your upcoming celebration. Reach out and let's craft something beautiful together.
        </motion.p>
      </section>

      <section className="py-8 md:py-16 px-5 md:px-6 pb-16 md:pb-32 w-full flex justify-center">
        <div className="w-full max-w-[1300px] grid grid-cols-1 lg:grid-cols-2 gap-10 md:gap-16 lg:gap-24 items-start">
          
          {/* Contact Details */}
          <motion.div
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          >
            <div className="w-8 h-[1px] bg-gold mb-6 md:mb-8" />
            <h2 className="font-display text-2xl md:text-4xl text-brown-dark mb-8 md:mb-10 font-light">Get in Touch</h2>
            
            <div className="space-y-8 md:space-y-12">
              <div className="flex gap-4 md:gap-6 group">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-brown-dark flex items-center justify-center shrink-0 text-gold group-hover:bg-gold group-hover:text-white transition-all duration-500">
                  <FaMapMarkerAlt className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-lg md:text-xl text-brown-dark mb-1 md:mb-2">Our Bakery</h3>
                  <p className="text-brown-light/60 font-light leading-[1.8] text-xs md:text-sm">
                    Jalgaon, Maharashtra, 425001<br/>India
                  </p>
                </div>
              </div>

              <div className="flex gap-4 md:gap-6 group">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-brown-dark flex items-center justify-center shrink-0 text-gold group-hover:bg-gold group-hover:text-white transition-all duration-500">
                  <FaPhoneAlt className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h3 className="font-display text-lg md:text-xl text-brown-dark mb-1 md:mb-2">Phone</h3>
                  <p className="text-brown-light/60 font-light leading-[1.8] text-xs md:text-sm">
                    +91 98340 63825<br/>
                    <span className="text-[9px] uppercase tracking-[0.2em] text-gold mt-1 block font-medium">Mon - Sat (10am to 8pm)</span>
                  </p>
                </div>
              </div>

              <div className="flex gap-4 md:gap-6 group">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-brown-dark flex items-center justify-center shrink-0 text-gold group-hover:bg-gold group-hover:text-white transition-all duration-500">
                  <FaEnvelope className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-lg md:text-xl text-brown-dark mb-1 md:mb-2">Email</h3>
                  <p className="text-brown-light/60 font-light leading-[1.8] text-xs md:text-sm break-all">
                    celesteehomebakes@gmail.com
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* WhatsApp CTA Box */}
          <motion.div
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="bg-brown-dark p-8 md:p-14 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.15)]"
          >
            <div className="w-8 h-[1px] bg-gold mb-6 md:mb-8" />
            <h3 className="font-display text-2xl md:text-3xl text-white mb-4 leading-tight font-light">
              Ready to Order?
            </h3>
            <p className="text-white/40 text-xs md:text-sm leading-[1.8] font-light mb-8 md:mb-10">
              For immediate assistance and rapid responses, we process all inquiries and custom orders directly via WhatsApp. Share your design ideas in real time.
            </p>
            
            <a
              href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-3 w-full py-4 bg-gold text-white hover:bg-white hover:text-brown-dark transition-all duration-500 font-semibold uppercase tracking-[0.15em] text-[10px] md:text-xs shadow-sm hover:shadow-lg"
            >
              <FaWhatsapp className="w-5 h-5" /> Chat with our Baker
            </a>
            
            <p className="text-center text-[9px] uppercase tracking-[0.2em] text-white/25 mt-5 md:mt-6 font-medium">
              Usually replies within 1 hour
            </p>
          </motion.div>
        </div>
      </section>

      {/* Map Strip */}
      <section className="h-48 sm:h-64 md:h-96 w-full grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-1000 bg-brown-dark/5">
        <iframe
          title="Jalgaon Map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1m3!1d119253.2847551062!2d75.49845348873499!3d20.99008271101831!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd90fa4a1eab90f%3A0x37f67bd21bff0a3c!2sJalgaon%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
          className="w-full h-full border-0"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>
    </main>
  )
}
