import { motion } from 'framer-motion'
import { FaWhatsapp } from 'react-icons/fa'

const services = [
  {
    title: 'Custom Birthday Cakes',
    desc: 'From your child\'s favorite character to a sophisticated floral masterpiece — we bring your vision to life with precision and luxury.',
    features: ['Any theme or design', 'Multiple sizes available', 'Silky fondant or cream finish', 'Edible photo printing'],
    image: 'https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?w=800&q=80',
  },
  {
    title: 'Wedding & Engagement Tiers',
    desc: 'Your wedding cake is a centerpiece as much as it is a dessert. We craft multi-tiered showpieces that are perfectly matched to your event aesthetic.',
    features: ['Elegant multi-tier designs', 'Bespoke floral & fondant decor', 'Private tasting session', 'Secure venue delivery'],
    image: 'https://images.unsplash.com/photo-1546074177-ffdda98d214f?w=800&q=80',
  },
  {
    title: 'Corporate & Gifting',
    desc: 'Make a lasting impression with bespoke gift boxes of delicate cupcakes and treats — perfectly curated for corporate gifting and premium events.',
    features: ['Bulk luxury orders', 'Custom branding integration', 'Premium presentation boxes', 'Citywide gentle delivery'],
    image: 'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?w=800&q=80',
  },
]

const steps = [
  { step: '01', title: 'Get in Touch', desc: 'Message us on WhatsApp with your date and initial ideas.' },
  { step: '02', title: 'We Design', desc: 'Our head baker discusses the exact design, flavour profile, and aesthetic.' },
  { step: '03', title: 'We Bake', desc: 'Every component is freshly baked on the day of your celebration.' },
  { step: '04', title: 'Safe Delivery', desc: 'We carefully package and deliver the masterpiece to your doorstep.' },
]

export default function Services() {
  return (
    <main className="pt-20 md:pt-24 bg-[#FDFBF9] min-h-screen">

      {/* Header */}
      <section className="py-16 md:py-24 px-5 md:px-6 text-center">
        <motion.p 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} 
          className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-4 md:mb-6 font-semibold"
        >Our Expertise</motion.p>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="font-display text-4xl md:text-6xl lg:text-7xl text-brown-dark mb-5 md:mb-6 leading-tight font-light"
        >
          Our Offerings
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="text-brown-light/70 text-sm md:text-base max-w-xl mx-auto font-light leading-[1.8]"
        >
          From intimate celebrations to grand masterpieces, we pour absolute dedication and heart into every single creation.
        </motion.p>
      </section>

      {/* Services List */}
      <section className="py-8 md:py-16 px-5 md:px-6 w-full flex justify-center">
        <div className="w-full max-w-[1300px] space-y-16 md:space-y-32">
          {services.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "0px 0px -80px 0px" }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-16 lg:gap-24 items-center ${i % 2 !== 0 ? 'lg:grid-flow-dense' : ''}`}
            >
              <div className={i % 2 !== 0 ? 'lg:col-start-2' : ''}>
                <div className="overflow-hidden aspect-[4/5] md:aspect-[4/5] border border-brown-light/5 shadow-[0_20px_50px_-15px_rgba(0,0,0,0.08)]">
                  <img
                    src={s.image}
                    alt={s.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-[2s] ease-out"
                  />
                </div>
              </div>
              
              <div className={i % 2 !== 0 ? 'lg:col-start-1 lg:row-start-1' : ''}>
                <p className="text-[9px] md:text-xs uppercase tracking-[0.3em] text-gold mb-3 md:mb-4 font-semibold">{`0${i + 1} — Service`}</p>
                <h2 className="font-display text-3xl md:text-4xl lg:text-5xl text-brown-dark mb-4 md:mb-6 leading-tight font-light">{s.title}</h2>
                <p className="text-brown-light/70 text-sm md:text-base leading-[1.9] font-light mb-6 md:mb-10 max-w-lg">{s.desc}</p>
                
                <ul className="space-y-3 md:space-y-4 mb-8 md:mb-12">
                  {s.features.map((f, fi) => (
                    <li key={fi} className="flex items-center gap-3 md:gap-4 text-brown-dark/70 text-xs md:text-sm font-light">
                      <div className="w-1 h-1 md:w-1.5 md:h-1.5 bg-gold rounded-full shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                
                <a
                  href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-3 px-7 md:px-8 py-3.5 bg-brown-dark text-white hover:bg-gold transition-all duration-500 text-[10px] md:text-xs font-semibold uppercase tracking-[0.15em] shadow-sm hover:shadow-lg"
                >
                  <FaWhatsapp className="w-4 h-4" /> Get Started
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 md:py-32 px-5 md:px-6 mt-8 md:mt-16 bg-brown-dark w-full flex justify-center">
        <div className="w-full max-w-[1300px]">
          <div className="text-center mb-16 md:mb-24">
            <p className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-4 font-semibold">How It Works</p>
            <h2 className="font-display text-3xl md:text-5xl text-white font-light">The Creative Process</h2>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-8">
            {steps.map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                className="relative text-center"
              >
                <span className="font-display text-5xl md:text-6xl text-white/5 block mb-4 md:mb-6 leading-none">{s.step}</span>
                <h3 className="font-display text-base md:text-xl text-white mb-2 md:mb-4">{s.title}</h3>
                <p className="text-white/40 text-[11px] md:text-sm leading-[1.8] font-light">{s.desc}</p>
                
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-[80%] w-[40%] h-[1px] bg-gradient-to-r from-gold/20 to-transparent" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
