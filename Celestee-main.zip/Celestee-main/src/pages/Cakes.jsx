import { useSearchParams } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { HiOutlineSearch } from 'react-icons/hi'
import axios from 'axios'
import ProductCard from '../components/ProductCard'

const cats = [
  { key: 'all',      label: 'All' },
  { key: 'cakes',    label: 'Cakes' },
  { key: 'cupcakes', label: 'Cupcakes' },
  { key: 'donuts',   label: 'Donuts' },
  { key: 'pastries', label: 'Pastries' },
  { key: 'custom',   label: 'Custom' },
]

export default function Cakes() {
  const [searchParams] = useSearchParams()
  const tagFilter = searchParams.get('tag')
  
  const [activeCat, setActiveCat] = useState('all')
  const [search, setSearch] = useState('')
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await axios.get('/api/products')
        setProducts(res.data)
      } catch {
        const { sampleProducts } = await import('../data/products')
        setProducts(sampleProducts)
      } finally {
        setLoading(false)
      }
    }
    fetchProducts()
  }, [])

  const filtered = products.filter(p => {
    const matchCat = activeCat === 'all' || p.category === activeCat
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase())
    const matchTag = !tagFilter || (p.tags && p.tags.some(t => t.toLowerCase() === tagFilter.toLowerCase()))
    return matchCat && matchSearch && matchTag
  })

  return (
    <main className="pt-20 md:pt-24 pb-20 md:pb-32 min-h-screen bg-[#FDFBF9]">
      
      {/* HEADER */}
      <section className="bg-white py-12 md:py-24 px-5 md:px-10 border-b border-brown-light/10 w-full flex justify-center">
        <div className="w-full max-w-[1300px] text-center">
          <motion.p 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-4 md:mb-6 font-semibold"
          >
            The Collection
          </motion.p>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ delay: 0.1 }}
            className="font-display text-4xl md:text-6xl lg:text-7xl text-brown-dark leading-tight font-light"
          >
            Our Cakes
          </motion.h1>
        </div>
      </section>

      <div className="w-full flex justify-center pb-20 md:pb-32">
        <div className="w-full max-w-[1300px] px-5 md:px-10">
          
          {/* Filter Bar */}
          <div className="flex flex-col gap-5 md:gap-0 md:flex-row items-start md:items-center justify-between pt-8 md:pt-12 pb-6 md:pb-8 mb-8 md:mb-16 border-b border-brown-light/10">
            
            {/* Tabs — horizontally scrollable on mobile */}
            <div className="flex items-center gap-3 md:gap-8 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-hide -mx-1 px-1">
              {cats.map(c => (
                <button
                  key={c.key}
                  onClick={() => setActiveCat(c.key)}
                  className={`relative text-[11px] md:text-xs uppercase tracking-[0.15em] font-medium transition-all duration-300 whitespace-nowrap py-2 px-3 md:px-0 rounded-full md:rounded-none ${
                    activeCat === c.key 
                      ? 'text-white md:text-brown-dark bg-brown-dark md:bg-transparent' 
                      : 'text-brown-light/50 hover:text-brown bg-transparent'
                  }`}
                >
                  {c.label}
                  {activeCat === c.key && (
                    <motion.div 
                      layoutId="activeTab" 
                      className="hidden md:block absolute bottom-0 left-0 right-0 h-[1.5px] bg-gold" 
                    />
                  )}
                </button>
              ))}
            </div>

            {/* Search */}
            <div className="relative w-full md:w-72 shrink-0">
              <HiOutlineSearch className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-brown-light/30" />
              <input
                type="text"
                placeholder="Search..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-7 pr-4 py-2.5 bg-transparent border-b border-brown-light/15 text-brown text-sm focus:outline-none focus:border-gold transition-colors placeholder:text-brown-light/25 font-light"
              />
            </div>
          </div>

          {/* Loading skeletons */}
          {loading && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-x-6 md:gap-y-12">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="aspect-[4/5] bg-cream-dark/40 animate-pulse" />
              ))}
            </div>
          )}

          {/* Product Grid — 2 cols on mobile, 4 on desktop */}
          {!loading && (
            <AnimatePresence mode="wait">
              {filtered.length > 0 ? (
                <motion.div
                  key={activeCat + search}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                  className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-x-6 md:gap-y-12"
                >
                  {filtered.map((p, i) => <ProductCard key={p._id || i} product={p} index={i} />)}
                </motion.div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }}
                  className="text-center py-20 md:py-32"
                >
                  <p className="font-display text-3xl md:text-4xl text-brown-dark mb-4">Nothing found</p>
                  <p className="text-brown-light/60 font-light text-sm">Try adjusting your search or category filters.</p>
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>
      </div>
    </main>
  )
}
