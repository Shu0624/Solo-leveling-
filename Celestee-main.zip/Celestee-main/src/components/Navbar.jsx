import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { HiOutlineShoppingBag, HiOutlineMenuAlt3, HiX, HiOutlineCog } from 'react-icons/hi'
import { useCart } from '../context/CartContext'

const navLinks = [
  { label: 'Home', to: '/' },
  { label: 'Our Cakes', to: '/cakes' },
  { label: 'Services', to: '/services' },
  { label: 'About', to: '/about' },
  { label: 'Get In Touch', to: '/contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const { cartCount, setIsCartOpen } = useCart()
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => setMobileOpen(false), [location])

  const isHome = location.pathname === '/'

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 w-full flex justify-center ${
          scrolled || !isHome
            ? 'bg-cream/95 backdrop-blur-xl border-b border-brown-light/10 py-3 md:py-4 shadow-[0_1px_30px_-10px_rgba(0,0,0,0.06)]'
            : 'bg-transparent py-5 md:py-6'
        }`}
      >
        <div className="w-full max-w-7xl px-5 md:px-12 flex items-center justify-between">
          
          {/* Logo */}
          <Link to="/" className="flex items-center shrink-0">
            {scrolled || !isHome ? (
              <span className="font-display text-2xl md:text-3xl text-brown-dark tracking-wide">Celestee's</span>
            ) : (
              <span className="font-display text-2xl md:text-4xl text-white drop-shadow-md tracking-wide">Celestee's</span>
            )}
          </Link>

          {/* Center Links (Desktop) */}
          <nav className="hidden lg:flex items-center justify-center gap-10 flex-1">
            {navLinks.map(l => (
              <Link key={l.to} to={l.to}
                className={`text-[11px] uppercase tracking-[0.18em] transition-all duration-300 font-medium hover:tracking-[0.22em] ${
                  location.pathname === l.to ? 'text-gold' : scrolled || !isHome ? 'text-brown-dark hover:text-gold' : 'text-white hover:text-gold drop-shadow-sm'
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center justify-end gap-4 md:gap-5 shrink-0">
            <button onClick={() => setIsCartOpen(true)} className="relative p-2">
              <HiOutlineShoppingBag className={`w-5 h-5 md:w-6 md:h-6 transition-colors ${scrolled || !isHome ? 'text-brown-dark hover:text-gold' : 'text-white hover:text-gold'}`} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-gold text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow-md">
                  {cartCount}
                </span>
              )}
            </button>
            <Link to="/admin" className="p-2 hidden lg:block" title="Admin Panel">
              <HiOutlineCog className={`w-5 h-5 transition-colors ${scrolled || !isHome ? 'text-brown-dark hover:text-gold' : 'text-white hover:text-gold'}`} />
            </Link>
            <button onClick={() => setMobileOpen(v => !v)} className="lg:hidden p-2 -mr-1">
              {mobileOpen
                ? <HiX className={`w-6 h-6 ${scrolled || !isHome ? 'text-brown-dark' : 'text-white'}`} />
                : <HiOutlineMenuAlt3 className={`w-6 h-6 ${scrolled || !isHome ? 'text-brown-dark' : 'text-white'}`} />
              }
            </button>
          </div>
        </div>
      </header>

      {/* ─── Premium Mobile Fullscreen Drawer ─── */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-brown-dark/60 backdrop-blur-md z-40 lg:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full max-w-sm bg-cream z-50 lg:hidden flex flex-col shadow-2xl"
            >
              {/* Header */}
              <div className="p-6 pt-7 flex items-center justify-between">
                <span className="font-display text-2xl text-brown-dark tracking-wide">Celestee's</span>
                <button onClick={() => setMobileOpen(false)} className="p-2 -mr-2 rounded-full hover:bg-pink-soft/30 transition-colors">
                  <HiX className="w-5 h-5 text-brown-dark" />
                </button>
              </div>
              
              {/* Divider */}
              <div className="mx-6 h-[1px] bg-gradient-to-r from-gold/30 via-gold/10 to-transparent" />
              
              {/* Nav Links */}
              <nav className="px-6 py-8 flex flex-col gap-1 flex-1">
                {navLinks.map((l, i) => (
                  <motion.div key={l.to} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 + i * 0.06 }}>
                    <Link to={l.to}
                      className={`flex items-center justify-between py-4 font-display text-2xl transition-all duration-300 ${
                        location.pathname === l.to ? 'text-gold' : 'text-brown-dark hover:text-gold hover:pl-2'
                      }`}
                    >
                      <span>{l.label}</span>
                      {location.pathname === l.to && (
                        <div className="w-2 h-2 rounded-full bg-gold" />
                      )}
                    </Link>
                  </motion.div>
                ))}
                
                <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 + navLinks.length * 0.06 }}>
                  <div className="h-[1px] bg-brown-light/10 my-4" />
                  <Link to="/admin" className="flex items-center gap-3 py-4 text-brown-light/70 hover:text-gold transition-colors">
                    <HiOutlineCog className="w-5 h-5" />
                    <span className="font-display text-lg">Admin Panel</span>
                  </Link>
                </motion.div>
              </nav>

              {/* Bottom branding */}
              <div className="p-6 border-t border-brown-light/10">
                <p className="text-[9px] uppercase tracking-[0.3em] text-brown-light/40 text-center font-medium">
                  Crafted with love in Jalgaon
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
