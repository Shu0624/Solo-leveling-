import { motion } from 'framer-motion'
import { useState } from 'react'
import CustomizeModal from './CustomizeModal'

export default function ProductCard({ product, index = 0 }) {
  const [modalOpen, setModalOpen] = useState(false)

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "0px 0px -50px 0px" }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: Math.min(index * 0.05, 0.2) }}
        className="group flex flex-col"
      >
        {/* Image Container */}
        <div className="relative w-full aspect-[4/5] bg-cream-dark/30 overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-[2s] ease-[0.22,1,0.36,1] group-hover:scale-105"
            loading="lazy"
          />

          {/* Dark overlay on hover */}
          <div className="absolute inset-0 bg-brown-dark/0 group-hover:bg-brown-dark/10 transition-colors duration-700" />

          {/* Bestseller Badge */}
          {product.bestseller && (
            <span className="absolute top-3 left-3 bg-gold text-white text-[8px] font-bold uppercase tracking-[0.2em] px-3 py-1.5 shadow-lg">
              ★ Bestseller
            </span>
          )}

          {/* Category pill */}
          <span className="absolute bottom-3 right-3 bg-black/40 backdrop-blur-sm text-white text-[8px] uppercase tracking-[0.15em] font-medium px-3 py-1.5">
            {product.category}
          </span>

          {/* Quick Add overlay on mobile (always visible on touch) */}
          <button
            onClick={() => setModalOpen(true)}
            className="absolute bottom-0 left-0 right-0 py-3.5 bg-brown-dark/90 backdrop-blur-sm text-white text-[10px] font-semibold uppercase tracking-[0.2em] 
                       opacity-0 group-hover:opacity-100 translate-y-full group-hover:translate-y-0 
                       transition-all duration-500 ease-out
                       md:block hidden"
          >
            Quick Add +
          </button>
        </div>

        {/* Info */}
        <div className="flex flex-col gap-2.5 pt-4 pb-1 px-0.5">
          <div className="flex justify-between items-start gap-3">
            <h3 className="font-display text-sm md:text-base text-brown-dark leading-snug group-hover:text-gold transition-colors duration-500 flex-1">
              {product.name}
            </h3>
            <span className="font-display text-sm md:text-base text-gold font-semibold tracking-wide shrink-0">
              ₹{product.price}
            </span>
          </div>

          {product.description && (
            <p className="text-[10px] md:text-[11px] text-brown-light/60 leading-relaxed line-clamp-2 font-light">
              {product.description}
            </p>
          )}

          {/* Mobile Add Button (always visible on small screens) */}
          <button
            onClick={() => setModalOpen(true)}
            className="md:hidden w-full mt-1 py-3 bg-brown-dark text-white text-[10px] font-semibold uppercase tracking-[0.2em] active:bg-gold transition-colors duration-300 flex items-center justify-center gap-2"
          >
            <span className="text-[11px]">+</span>
            Add to Order
          </button>

          {/* Desktop Add Button */}
          <button
            onClick={() => setModalOpen(true)}
            className="hidden md:flex w-full mt-1 py-3 border border-brown-dark/15 text-brown-dark text-[10px] font-semibold uppercase tracking-[0.2em] hover:bg-brown-dark hover:text-white hover:border-brown-dark transition-all duration-300 items-center justify-center gap-2"
          >
            <span className="text-[11px]">+</span>
            Add to Order
          </button>
        </div>
      </motion.div>

      <CustomizeModal isOpen={modalOpen} onClose={() => setModalOpen(false)} product={product} />
    </>
  )
}
