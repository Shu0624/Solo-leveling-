import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { FaWhatsapp, FaInstagram, FaFacebookF } from 'react-icons/fa'
import { HiMail, HiPhone, HiLocationMarker } from 'react-icons/hi'

export default function Footer() {
  return (
    <>
      {/* CTA Section */}
      <section className="bg-brown-dark py-20 md:py-28 relative overflow-hidden">
        {/* Subtle gold accent line */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-[1px] bg-gold" />
        
        <div className="max-w-7xl mx-auto px-5 md:px-12 text-center relative z-10">
          <p className="text-[9px] md:text-[10px] uppercase tracking-[0.4em] text-gold mb-6 font-semibold">Ready to Indulge?</p>
          <h2 className="font-display text-3xl md:text-5xl lg:text-6xl text-white mb-10 md:mb-12 max-w-3xl mx-auto leading-[1.15] font-light">
            Experience the magic of<br />handcrafted bakes.
          </h2>
          <a href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer"
            className="inline-flex items-center gap-3 px-8 md:px-10 py-4 bg-gold text-white text-[10px] md:text-[11px] font-bold uppercase tracking-[0.2em] hover:bg-white hover:text-brown-dark transition-all duration-500 shadow-lg"
          >
            <FaWhatsapp className="w-5 h-5" /> Order on WhatsApp
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1A110C] pt-16 md:pt-24 pb-10 md:pb-12">
        <div className="max-w-7xl mx-auto px-5 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-8">
          
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="inline-block mb-6">
              <span className="font-display text-2xl md:text-3xl text-gold tracking-wide">Celestee's</span>
            </Link>
            <p className="text-white/50 text-xs md:text-sm leading-relaxed mb-6 max-w-xs font-light">
              Crafting sweet memories with premium ingredients and unparalleled love. Based in Jalgaon.
            </p>
            <div className="flex items-center gap-5">
              <a href="#" className="text-white/40 hover:text-gold transition-colors duration-300"><FaInstagram className="w-4 h-4" /></a>
              <a href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`} className="text-white/40 hover:text-gold transition-colors duration-300"><FaWhatsapp className="w-4 h-4" /></a>
              <a href="#" className="text-white/40 hover:text-gold transition-colors duration-300"><FaFacebookF className="w-4 h-4" /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[10px] uppercase tracking-[0.3em] font-semibold text-gold mb-6 md:mb-8">Navigation</h4>
            <ul className="flex flex-col gap-3 md:gap-4">
              {[
                { label: 'Home', to: '/' },
                { label: 'Our Collection', to: '/cakes' },
                { label: 'Services', to: '/services' },
                { label: 'Our Story', to: '/about' },
                { label: 'Contact', to: '/contact' }
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-white/50 text-xs md:text-sm hover:text-gold transition-colors duration-300 font-light">{link.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="col-span-2">
            <h4 className="text-[10px] uppercase tracking-[0.3em] font-semibold text-gold mb-6 md:mb-8">Get In Touch</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8">
              <div className="space-y-5">
                <div className="flex items-start gap-3">
                  <HiLocationMarker className="w-4 h-4 text-gold/60 shrink-0 mt-0.5" />
                  <p className="text-white/50 text-xs md:text-sm leading-relaxed font-light">
                    Jalgaon, Maharashtra<br />India
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <HiPhone className="w-4 h-4 text-gold/60 shrink-0" />
                  <a href="tel:+919834063825" className="text-white/50 text-xs md:text-sm hover:text-gold transition-colors font-light">+91 87676 37586</a>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <HiMail className="w-4 h-4 text-gold/60 shrink-0 mt-0.5" />
                <a href="mailto:celesteehomebakes@gmail.com" className="text-white/50 text-xs md:text-sm hover:text-gold transition-colors font-light break-all">celesteehomebakes@gmail.com</a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="max-w-7xl mx-auto px-5 md:px-12 mt-14 md:mt-20 pt-6 md:pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[9px] uppercase tracking-[0.2em] text-white/25 font-medium text-center md:text-left">
            © 2026 Celestee's Home Bakes. All rights reserved.
          </p>
          <span className="text-[9px] uppercase tracking-[0.3em] text-gold/40 italic font-medium">Baked with love, just like home.</span>
        </div>
      </footer>
    </>
  )
}
