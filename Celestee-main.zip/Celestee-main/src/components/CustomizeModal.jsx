import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { HiX, HiOutlineShoppingCart } from 'react-icons/hi'
import { FaWhatsapp } from 'react-icons/fa'
import { useCart } from '../context/CartContext'
import axios from 'axios'

const FLAVOURS = ['Dutch Chocolate', "Gulliver's Gold", 'Swiss Chocolate', 'Vanilla Bean']
const WEIGHTS = [0.5, 1, 1.5, 2]

export default function CustomizeModal({ isOpen, onClose, product }) {
  const { addToCart } = useCart()
  
  const [flavour, setFlavour] = useState(FLAVOURS[0])
  const [weight, setWeight] = useState(0.5)
  const [message, setMessage] = useState('')
  const [customerInfo, setCustomerInfo] = useState({ name: '', phone: '' })
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Calculate dynamic price based on weight modifier (assuming base price is for 0.5kg)
  const finalPrice = product ? product.price * (weight / 0.5) : 0

  const handleAddToCart = () => {
    addToCart({
      ...product,
      price: finalPrice,
      custom_flavour: flavour,
      custom_weight: weight,
      custom_message: message
    })
    onClose()
  }

  const handleCheckout = async () => {
    if (!customerInfo.name || !customerInfo.phone) {
      alert("Please enter your Name and WhatsApp phone number to proceed.")
      return
    }

    setIsSubmitting(true)
    try {
      // 1. Send Order to Admin Database
      await axios.post('/api/orders', {
        customerName: customerInfo.name,
        phone: customerInfo.phone,
        address: 'WhatsApp Order', // Default for now
        message: `Flavour: ${flavour}, Weight: ${weight}kg, Cake Msg: "${message}"`,
        items: [{
          productId: product._id,
          name: product.name,
          price: finalPrice,
          quantity: 1,
          image: product.image
        }],
        total: finalPrice,
      })
      console.log("✅ Order saved to Admin Database")

      // 2. Open WhatsApp Message
      const waText = `Hello Celestee's! I'd like to order:
*${product.name}*
Flavour: ${flavour}
Weight: ${weight}kg
Message on Cake: ${message || 'None'}
Price: ₹${finalPrice}

My Name: ${customerInfo.name}
Phone: ${customerInfo.phone}`

      window.open(`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}?text=${encodeURIComponent(waText)}`, '_blank')
      
      onClose()
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!product) return null

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 py-10 overflow-y-auto pointer-events-none">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[24px] w-full max-w-4xl shadow-2xl flex flex-col md:flex-row overflow-hidden pointer-events-auto"
            >
              
              {/* Left Side: Image */}
              <div className="md:w-5/12 bg-cream/30 relative">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover aspect-square md:aspect-auto md:absolute inset-0" />
              </div>

              {/* Right Side: Customize Form */}
              <div className="flex-1 p-6 md:p-8 lg:p-10 flex flex-col max-h-[85vh] overflow-y-auto">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="font-display text-2xl text-brown-dark mb-2">{product.name}</h2>
                    <span className="font-display text-3xl text-pink-deep font-bold">₹{finalPrice}</span>
                  </div>
                  <button onClick={onClose} className="p-2 -mr-2 text-brown-light hover:text-brown bg-gray-50 rounded-full">
                    <HiX className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-8 flex-1">
                  
                  {/* Flavour */}
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest text-brown-dark block mb-3">Flavour <span className="text-pink-deep">*</span></label>
                    <div className="flex flex-wrap gap-2">
                      {FLAVOURS.map(f => (
                        <button key={f} onClick={() => setFlavour(f)} className={`px-4 py-2 rounded-full text-xs font-medium border transition-colors ${flavour === f ? 'bg-pink-deep text-white border-pink-deep' : 'bg-white text-brown border-pink-soft/50 hover:border-pink-deep'}`}>
                          {f}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Weight */}
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest text-brown-dark block mb-3">Weight <span className="text-pink-deep">*</span></label>
                    <div className="flex flex-wrap gap-2">
                      {WEIGHTS.map(w => (
                        <button key={w} onClick={() => setWeight(w)} className={`px-4 py-2 rounded-full text-xs font-medium border transition-colors ${weight === w ? 'bg-pink-deep text-white border-pink-deep' : 'bg-white text-brown border-pink-soft/50 hover:border-pink-deep'}`}>
                          {w} Kg
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest text-brown-dark block mb-3">Message on Cake</label>
                    <input 
                      type="text" 
                      maxLength={30}
                      placeholder="Enter your message (max 30 characters)"
                      value={message}
                      onChange={e => setMessage(e.target.value)}
                      className="w-full border border-pink-soft/50 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-pink-deep transition-colors text-brown-dark"
                    />
                    <p className="text-[10px] text-brown-light mt-1.5 text-right">{message.length}/30 characters</p>
                  </div>

                  <hr className="border-pink-soft/30" />

                  {/* Customer Info (Crucial for Admin Orders) */}
                  <div className="grid grid-cols-2 gap-4">
                     <div>
                       <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">Your Name <span className="text-pink-deep">*</span></label>
                       <input type="text" value={customerInfo.name} onChange={e=>setCustomerInfo({...customerInfo, name: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep" placeholder="Name" />
                     </div>
                     <div>
                       <label className="text-[10px] font-semibold uppercase tracking-widest text-brown-dark block mb-2">WhatsApp No. <span className="text-pink-deep">*</span></label>
                       <input type="text" value={customerInfo.phone} onChange={e=>setCustomerInfo({...customerInfo, phone: e.target.value})} className="w-full border border-brown-light/20 rounded-lg px-3 py-2 text-sm focus:border-pink-deep" placeholder="+91" />
                     </div>
                  </div>

                </div>

                {/* Footer Actions */}
                <div className="mt-8 pt-6 border-t border-pink-soft/30 flex flex-col sm:flex-row gap-4 items-center justify-end">
                  <button 
                    onClick={handleAddToCart}
                    className="w-full sm:w-auto px-8 py-3.5 rounded-full border border-pink-deep text-pink-deep hover:bg-pink-soft/20 transition-colors text-xs font-semibold tracking-widest uppercase flex items-center justify-center gap-2"
                  >
                    <HiOutlineShoppingCart className="w-4 h-4" /> Add to Cart
                  </button>
                  <button 
                    onClick={handleCheckout}
                    disabled={isSubmitting}
                    className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-pink-deep text-white hover:bg-brown-dark transition-all duration-300 text-xs font-semibold tracking-widest uppercase shadow-md flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? 'Processing...' : <><FaWhatsapp className="w-4 h-4"/> Checkout</>}
                  </button>
                </div>
              </div>

            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  )
}
