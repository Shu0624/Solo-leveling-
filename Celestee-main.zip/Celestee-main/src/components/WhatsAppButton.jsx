import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FaWhatsapp } from 'react-icons/fa'
import { HiX } from 'react-icons/hi'

export default function WhatsAppButton() {
  const [isOpen, setIsOpen] = useState(false)

  const handleChatStart = () => {
    window.open(`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}?text=Hi%20Celestee's,%20I'd%20love%20to%20place%20an%20order!`, "_blank")
    setIsOpen(false)
  }

  return (
    <div className="fixed bottom-6 right-6 z-[99]? flex flex-col items-end gap-4 pointer-events-none">
      
      {/* ── Chat Card ── */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20, originY: '100%', originX: '100%' }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="w-[320px] bg-white rounded-[24px] shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden pointer-events-auto border border-gray-100 mb-2"
          >
            {/* Header */}
            <div className="bg-[#075E54] p-5 text-white relative">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-xl">
                  <FaWhatsapp />
                </div>
                <div>
                  <h3 className="text-sm font-bold tracking-wide">Celestee's Home Bakes</h3>
                  <p className="text-[10px] opacity-80 font-medium">Typically replies within minutes</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="absolute top-4 right-4 p-1 hover:bg-white/10 rounded-full transition-colors"
              >
                <HiX className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Body */}
            <div className="p-6 bg-[#F0EBE3] min-h-[140px] relative">
              {/* Message Bubble */}
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white p-4 rounded-tr-xl rounded-br-xl rounded-bl-xl shadow-sm max-w-[85%] relative"
              >
                <p className="text-sm text-brown-dark leading-relaxed">
                  Hello! 👋 Welcome to <span className="font-bold">Celestee's</span>.<br />
                  How can we help you with your dream cake today?
                </p>
                <span className="text-[9px] text-gray-400 absolute bottom-1 right-2 italic">just now</span>
              </motion.div>
            </div>

            {/* Action Area */}
            <div className="p-4 bg-white border-t border-gray-50 flex justify-center">
              <button
                onClick={handleChatStart}
                className="w-full py-3.5 bg-[#25D366] text-white rounded-full flex items-center justify-center gap-2 text-sm font-bold shadow-md hover:bg-[#128C7E] transition-all transform active:scale-95"
              >
                <FaWhatsapp className="w-5 h-5" /> Start Chat
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Main Toggle Button ── */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 pointer-events-auto ${isOpen ? 'bg-white text-brown-dark' : 'bg-[#25D366] text-white'}`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <HiX className="w-7 h-7" />
            </motion.div>
          ) : (
            <motion.div key="whatsapp" initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}>
              <FaWhatsapp className="w-8 h-8" />
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Subtle Pulse Effect (only when closed) */}
        {!isOpen && (
          <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-20 pointer-events-none" />
        )}
      </motion.button>

    </div>
  )
}
