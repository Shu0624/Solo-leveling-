import express from 'express'
import cors from 'cors'
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

import authRoutes from './routes/auth.js'
import productRoutes from './routes/products.js'
import orderRoutes from './routes/orders.js'
import settingsRoutes from './routes/settings.js'
import clientRoutes from './routes/clients.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

dotenv.config({ path: path.join(__dirname, '../.env') })
// Fallback for local .env if root one is missing
dotenv.config()

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/products', productRoutes)
app.use('/api/orders', orderRoutes)
app.use('/api/settings', settingsRoutes)
app.use('/api/clients', clientRoutes)

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Anti-Gravity Cake Studio API is running ✨' })
})

// Connect to MongoDB and start server
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('✅ Connected to MongoDB')
    // Only listen if not running in a serverless environment
    if (process.env.NODE_ENV !== 'production') {
      app.listen(PORT, () => {
        console.log(`🚀 Server running on port ${PORT}`)
        console.log(`🎂 Anti-Gravity Cake Studio API ready!`)
      })
    }
  })
  .catch((err) => {
    console.error('❌ MongoDB connection error:', err.message)
    if (process.env.NODE_ENV !== 'production') {
      // Start server anyway for frontend-only development
      app.listen(PORT, () => {
        console.log(`⚠️ Server running on port ${PORT} (without database)`)
      })
    }
  })

export default app
