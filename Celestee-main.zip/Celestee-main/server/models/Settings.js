import mongoose from 'mongoose'

const settingsSchema = new mongoose.Schema({
  // Use a singleton doc with a fixed key
  key: { type: String, default: 'site', unique: true },
  aboutTitle: { type: String, default: "Baked with heart, gifted with love." },
  aboutText: { type: String, default: "Based in Jalgaon, Maharashtra, every creation at Celestee's is a piece of our heart — made from the finest real ingredients, no shortcuts, no preservatives. Just pure love baked into every bite." },
  aboutImage: { type: String, default: "https://images.unsplash.com/photo-1556217477-d325251ece38?w=1200&q=85" },
}, { timestamps: true })

export default mongoose.model('Settings', settingsSchema)
