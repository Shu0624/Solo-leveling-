import mongoose from 'mongoose'

const clientSchema = new mongoose.Schema({
  name: { type: String, required: true },
  image: { type: String, required: true },
  review: { type: String, default: '' },
}, { timestamps: true })

export default mongoose.model('HappyClient', clientSchema)
