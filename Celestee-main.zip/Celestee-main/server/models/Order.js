import mongoose from 'mongoose'

const orderSchema = new mongoose.Schema({
  customerName: { type: String, required: true },
  phone: { type: String, required: true },
  address: { type: String, required: true },
  deliveryDate: { type: String },
  message: { type: String, default: '' },
  items: [{
    productId: String,
    name: String,
    price: Number,
    quantity: Number,
    image: String,
  }],
  total: { type: Number, required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected', 'delivered'], default: 'pending' },
}, { timestamps: true })

export default mongoose.model('Order', orderSchema)
