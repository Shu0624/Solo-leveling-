import mongoose from 'mongoose'

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  category: { type: String, enum: ['cakes', 'cupcakes', 'donuts', 'custom'], required: true },
  description: { type: String, default: '' },
  image: { type: String, default: '' },
  featured: { type: Boolean, default: false },
  bestseller: { type: Boolean, default: false },
  tags: { type: [String], default: [] },
}, { timestamps: true })

export default mongoose.model('Product', productSchema)
