import mongoose from 'mongoose'
import dotenv from 'dotenv'
import Product from './models/Product.js'

dotenv.config()

const sampleProducts = [
  {
    name: 'Chocolate Truffle',
    price: 350,
    category: 'cakes',
    description: 'Decadent dark chocolate sponge layered with silky truffle ganache.',
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&q=80',
    featured: true,
    bestseller: true,
  },
  {
    name: 'Butterscotch Dream',
    price: 300,
    category: 'cakes',
    description: 'Airy vanilla sponge soaked in butterscotch sauce, layered with caramel cream.',
    image: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=800&q=80',
    featured: true,
    bestseller: false,
  },
  {
    name: 'Red Velvet',
    price: 400,
    category: 'cakes',
    description: 'Vivid crimson sponge with a hint of cocoa, every layer spread generously with cream cheese frosting.',
    image: 'https://images.unsplash.com/photo-1616541823729-00fe0aacd32c?w=800&q=80',
    featured: true,
    bestseller: true,
  },
  {
    name: 'Black Forest',
    price: 350,
    category: 'cakes',
    description: 'German-inspired classic: chocolate sponge, fresh cream, kirsch-soaked cherries.',
    image: 'https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?w=800&q=80',
    featured: false,
    bestseller: true,
  },
  {
    name: 'Red Velvet Cupcake',
    price: 80,
    category: 'cupcakes',
    description: 'Our beloved red velvet in a charming individual serving.',
    image: 'https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?w=800&q=80',
    featured: true,
    bestseller: false,
  },
  {
    name: 'Chocolate Cupcake',
    price: 70,
    category: 'cupcakes',
    description: 'Moist rich chocolate base topped with a generous swirl of dark chocolate buttercream.',
    image: 'https://images.unsplash.com/photo-1588195538320-a544b80a5e82?w=800&q=80',
    featured: false,
    bestseller: false,
  },
  {
    name: 'Oreo Donut',
    price: 100,
    category: 'donuts',
    description: 'Pillowy fried yeast donut with white chocolate glaze and a generous crown of crushed Oreo crumbles.',
    image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=800&q=80',
    featured: true,
    bestseller: true,
  },
  {
    name: 'Classic Glazed Donut',
    price: 80,
    category: 'donuts',
    description: 'The timeless golden yeast donut with a perfectly thin, shimmering sugar glaze.',
    image: 'https://images.unsplash.com/photo-1514517521153-1be72277b32f?w=800&q=80',
    featured: false,
    bestseller: false,
  },
  {
    name: 'The Celestee Signature',
    price: 1500,
    category: 'custom',
    description: 'Your vision, our craft. A fully bespoke creation designed for your most precious moments. Contact us to begin.',
    image: 'https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?w=800&q=80',
    featured: true,
    bestseller: false,
  },
]

const seedDB = async () => {
  try {
    if (!process.env.MONGODB_URI) {
      console.error('❌ MONGODB_URI is not defined in .env file.')
      process.exit(1)
    }

    await mongoose.connect(process.env.MONGODB_URI)
    console.log('✅ Connected to MongoDB')

    await Product.deleteMany({})
    console.log('🧹 Cleared existing products')

    await Product.insertMany(sampleProducts)
    console.log('🌟 Successfully seeded products into the database!')

    process.exit(0)
  } catch (err) {
    console.error('❌ Seed failed:', err.message)
    process.exit(1)
  }
}

seedDB()
