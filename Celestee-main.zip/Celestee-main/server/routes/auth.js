import { Router } from 'express'
import jwt from 'jsonwebtoken'
import Admin from '../models/Admin.js'

const router = Router()

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email: rawEmail, password: rawPassword } = req.body
    
    // Strict cleaning: Strip ALL whitespace (newlines, tabs, spaces)
    const email = rawEmail?.replace(/\s+/g, '').toLowerCase()
    const password = rawPassword?.replace(/\s+/g, '')

    // 1. Check Master Credentials from .env
    const masterEmail = process.env.ADMIN_EMAIL?.replace(/\s+/g, '').toLowerCase()
    const masterPassword = process.env.ADMIN_PASSWORD?.replace(/\s+/g, '')

    console.log('--- LOGIN DEBUG ---')
    console.log(`Input Email: [${email}] (len: ${email?.length})`)
    console.log(`Master Email: [${masterEmail}] (len: ${masterEmail?.length})`)
    console.log('Password Match:', password === masterPassword)
    console.log('--- END DEBUG ---')

    if (masterEmail && email === masterEmail && masterPassword && password === masterPassword) {
      console.log(`🔐 Master login successful for: ${email}`)
      const token = jwt.sign({ id: 'master_admin', role: 'admin' }, process.env.JWT_SECRET, { expiresIn: '7d' })
      return res.json({ token, message: 'Login successful (Master Admin)' })
    }

    console.log(`👤 Database login attempt for: ${email}`)
    // 2. Fallback to Database
    const admin = await Admin.findOne({ email })
    if (!admin) return res.status(401).json({ message: 'Invalid credentials' })

    const isMatch = await admin.comparePassword(password)
    if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' })

    const token = jwt.sign({ id: admin._id }, process.env.JWT_SECRET, { expiresIn: '7d' })
    res.json({ token, message: 'Login successful' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

export default router
