import { Router } from 'express'
import HappyClient from '../models/HappyClient.js'
import auth from '../middleware/auth.js'

const router = Router()

// GET /api/clients — public
router.get('/', async (req, res) => {
  try {
    const clients = await HappyClient.find().sort({ createdAt: -1 })
    res.json(clients)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

// POST /api/clients — admin only
router.post('/', auth, async (req, res) => {
  try {
    const client = await HappyClient.create(req.body)
    res.status(201).json(client)
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

// DELETE /api/clients/:id — admin only
router.delete('/:id', auth, async (req, res) => {
  try {
    await HappyClient.findByIdAndDelete(req.params.id)
    res.json({ message: 'Client deleted' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

export default router
