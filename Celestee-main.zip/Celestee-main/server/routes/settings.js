import express from 'express'
import jwt from 'jsonwebtoken'
import Settings from '../models/Settings.js'

const router = express.Router()

// Auth middleware
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ message: 'Unauthorized' })
  try {
    req.admin = jwt.verify(token, process.env.JWT_SECRET)
    next()
  } catch {
    res.status(401).json({ message: 'Invalid token' })
  }
}

// GET /api/settings — public, get site settings
router.get('/', async (req, res) => {
  try {
    // findOneAndUpsert — ensures the singleton always exists
    let settings = await Settings.findOne({ key: 'site' })
    if (!settings) settings = await Settings.create({ key: 'site' })
    res.json(settings)
  } catch (err) {
    res.status(500).json({ message: 'Error fetching settings' })
  }
})

// PUT /api/settings — admin only, update site settings
router.put('/', auth, async (req, res) => {
  try {
    const { aboutTitle, aboutText, aboutImage } = req.body
    const settings = await Settings.findOneAndUpdate(
      { key: 'site' },
      { aboutTitle, aboutText, aboutImage },
      { new: true, upsert: true }
    )
    res.json(settings)
  } catch (err) {
    res.status(500).json({ message: 'Error updating settings' })
  }
})

export default router
