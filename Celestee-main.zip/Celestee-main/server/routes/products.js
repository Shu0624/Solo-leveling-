import { Router } from 'express'
import Product from '../models/Product.js'
import auth from '../middleware/auth.js'

const router = Router()

// GET /api/products — public
router.get('/', async (req, res) => {
  try {
    const { category, featured, bestseller, tag } = req.query
    const filter = {}
    if (category) filter.category = category
    if (featured === 'true') filter.featured = true
    if (bestseller === 'true') filter.bestseller = true
    if (tag) filter.tags = { $regex: new RegExp(tag, 'i') } // case insensitive tag match
    const products = await Product.find(filter).sort({ createdAt: -1 })
    res.json(products)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

// GET /api/products/:id — public
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
    if (!product) return res.status(404).json({ message: 'Product not found' })
    res.json(product)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

// POST /api/products — admin only
router.post('/', auth, async (req, res) => {
  try {
    const product = await Product.create(req.body)
    res.status(201).json(product)
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

// PUT /api/products/:id — admin only
router.put('/:id', auth, async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true })
    if (!product) return res.status(404).json({ message: 'Product not found' })
    res.json(product)
  } catch (err) {
    res.status(400).json({ message: err.message })
  }
})

// DELETE /api/products/:id — admin only
router.delete('/:id', auth, async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id)
    res.json({ message: 'Product deleted' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

export default router
